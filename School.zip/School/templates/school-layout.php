<?php
/*
Template Name: New Layout
*/
?>

<?php
get_header();


if(have_posts()){
	while(have_posts()){
		the_post(); ?>
		<h1><a href="<?php echo get_the_permalink(); ?>"><?php the_title(); ?></a></h1>
		<p><?php the_content(); ?></p>

<?php	}
}
?>
<h3>New Layout</h3>
<?php
get_footer();
?>