<?php get_header(); 


?>




		<!-- contact start -->
<div class="container border border-dark mb-5 mt-5" style="margin-top: 120px !important;">
	<div class="row">
		<div class="col-sm-8">
<?php
 //include('contactform.php');

if(is_home()){
	echo "This is our home page";
}
if(is_front_page()){
	echo "This is Front page.";
}

if(have_posts()){
	while(have_posts()){ 
         the_post();
           get_template_part("template-parts/content", get_post_format());

	}
}else{
	echo "No Post Found";
}
?>
<h2>Search Page</h2>
</div>
<div class="col-sm-4">
	<?php get_search_form(); 

	echo get_search_query(); ?>
</div>
</div>
</div>


<?php get_footer(); ?>
