<footer class="container-fluid bg-dark mt-5" style="border-top: 3px solid #DC3545;">
	<div class="container">
		<div class="row py-3">
			<div class="col-md-6">
				<!-- footer 1st column start-->
             <span>
             	<a href="#" target="_blank" class="pr-2 fi-color"><i class="fab fa-facebook-f"></i></a>
             	<a href="#" target="_blank" class="pr-2 fi-color"><i class="fab fa-twitter"></i></a>
             	<a href="#" target="_blank" class="pr-2 fi-color"><i class="fab fa-youtube"></i></a>
             	<a href="#" target="_blank" class="pr-2 fi-color"><i class="fab fa-google-plus-g"></i></a>
             	<a href="#" target="_blank" class="pr-2 fi-color"><i class="fas fa-rss"></i></a>
             </span>
         </div>
                 <!-- footer 1st column end -->
                 <!-- footer 2nd column start -->
                 <div class="col-md-6 text-right text-white">
                 	<?php $pageid = get_option('footer_link_value');
                 	 ?>
				<small><?php echo get_option('footer_setting'); ?> &copy; 2020</small>
				<small><a href="<?php echo get_the_permalink($pageid); ?>"><?php echo get_option('footer_setting_link'); ?></a></small>
			</div>
			<!-- footer 2nd column end -->
		
		</div>
	</div>
</footer>
<script>
	// var ele = document.getElementsByClassName('del');
	// ele[0].children[12].style.display = "none";
</script>
<!-- -Bootstrap JavaScript----->
<?php wp_footer(); ?>
</body>
</html>