<!DOCTYPE html>
<html <?php echo language_attributes(); ?>>
<head>
	<meta charset="<?php echo get_bloginfo('charset'); ?>">
	<title><?php echo get_bloginfo('name'); ?> | <?php echo get_bloginfo('description'); ?></title>


   <?php wp_head(); ?>
	<link href="https://fonts.googleapis.com/css2?family=Ubuntu:wght@300&display=swap" rel="stylesheet">
</head>
<body>

	<?php 
$img = get_bloginfo('template_url').'/image/avtar1.jpeg'; 
$custom_logo_id = get_theme_mod('custom_logo');
					$logo = wp_get_attachment_image_src($custom_logo_id, 'full');
					if(has_custom_logo()){
						$img = esc_url($logo[0]);
						// $img = "one";
					}

?>


<h5 class="bg-success">This is header Name</h5>