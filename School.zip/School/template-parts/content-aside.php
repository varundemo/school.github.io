
<div class="container post mt-3  text-center border border-warning">
	<h3>Content Aside</h3>
<h5 class="border" style="display: inline;"><a class="mylink" href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h5>
<?php the_time('F j,Y g:i a'); ?> | <a href="<?php echo get_author_posts_url(get_the_author_meta('ID')); ?>"><?php the_author(); ?></a> |
<?php 
$cat = get_the_category();
$sep = ", ";
$newcat = "";
foreach ($cat as $value) {
	# code...
	// $newcat = $value->cat_name.$sep;
	$newcat .= "<a href='".get_category_link($value->term_id)."'>".$value->cat_name."</a>".$sep;
	// echo $newcat;
	// echo trim($newcat,$sep);
}
// echo $newcat;
echo trim($newcat,$sep);
?>
<div class="row del mt-2 border">
<div class="col-sm-4 pl-5 border border-primary pb-2 bg-danger pt-2">
<?php 
if(has_post_thumbnail()){
  the_post_thumbnail('small-thumbnail');
}else{
	echo '<img src="'.get_template_directory_uri().'/image/avtar1.jpeg'.'" style="width:120px; height:120px">';
}
?>	
</div>
<div class="col-sm-8">
<?php the_content(); ?>
	
</div>
</div>
</div>