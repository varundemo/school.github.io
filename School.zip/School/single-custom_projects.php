<?php get_header(); ?>



		<!-- contact start -->
<div class="container border border-dark mb-5 mt-5" style="margin-top: 120px !important;">
<?php
 //include('contactform.php');

if(have_posts()){
	while(have_posts()){ 
         the_post();
           get_template_part("template-parts/content", get_post_format());

	}
}
?>
<h3>Custom PHP</h3>
</div>


<?php get_footer(); ?>
