<?php get_header(); 


?>




		<!-- contact start -->
<div class="container border border-dark mb-5 mt-5" style="margin-top: 120px !important;">
	<div class="row">
		<div class="col-sm-8">
<?php
 //include('contactform.php');

if(is_home()){
	echo "This is our home page";
}
if(is_front_page()){
	echo "This is Front page.";
}

if(have_posts()){
	while(have_posts()){ 
         the_post();
           get_template_part("template-parts/content", get_post_format());

	}
}
?>
<h2>Front Page</h2>
</div>
<div class="col-sm-4">
	<h4>Sample Image</h4>
	<img src="<?php echo get_option('stu_image'); ?>" alt="">
	<?php //get_search_form(); ?>
	<?php dynamic_sidebar('sidebar-1'); ?>
</div>
</div>
</div>


<?php get_footer(); ?>
