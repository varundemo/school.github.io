<?php get_header(); 


?>




		<!-- contact start -->
<div class="container border border-dark mb-5 mt-5 text-center" style="margin-top: 120px !important;">
	
<h1>Page Not Found</h1><br><br>
<a href="<?php echo home_url('/') ?>" class="btn btn-primary">Back To Home</a>
</div>


<?php


 get_footer(); ?>
