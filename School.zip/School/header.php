<!DOCTYPE html>
<html <?php echo language_attributes(); ?>>
<head>
	<meta charset="<?php echo get_bloginfo('charset'); ?>">
	<title><?php echo get_bloginfo('name'); ?> | <?php echo get_bloginfo('description'); ?></title>


   <?php wp_head(); ?>
	<link href="https://fonts.googleapis.com/css2?family=Ubuntu:wght@300&display=swap" rel="stylesheet">
</head>
<body>

	<?php 
$img = get_bloginfo('template_url').'/image/avtar1.jpeg'; 
$custom_logo_id = get_theme_mod('custom_logo');
					$logo = wp_get_attachment_image_src($custom_logo_id, 'full');
					if(has_custom_logo()){
						$img = esc_url($logo[0]);
						// $img = "one";
					}

?>
<!-- start navigation -->
<nav class="navbar navbar-expand-sm navbar-dark bg-primary pl-5 fixed-top border border-dark" style="background-color: <?php echo get_option('stu_color'); ?> !important;">
	<a href="index.php" class="navbar-brand logo"><img src="<?php echo $img; ?>" alt=""></a>
	<span class="navbar-text">Customer Happiness is Our Aim</span>
	<button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#myMenu">
		<span class="navbar-toggler-icon"></span>
	</button>
	<div class="collapse navbar-collapse custom_menu" id="myMenu">
<?php
	if(has_nav_menu("primary_menu")){
     wp_nav_menu(array(
     	'menu'=>'primary_menu',
     	'menu_class'=>'new class',
     	'menu_id'=>'new id',
	'container'=>'',
	'items_warp'=>'<ul class="navbar-nav pl-5 custom-nav"></ul>'
));
	}
	

?>	
	</div>
</nav>
<!-- end navigation -->

