<?php get_header(); ?>


<h3>Single PHP</h3>

		<!-- contact start -->
<div class="container border border-dark mb-5 mt-5" style="margin-top: 120px !important;">
<?php
 //include('contactform.php');

if(have_posts()){
	while(have_posts()){ 
         the_post();
           get_template_part("template-parts/content", get_post_format());

	}
}
?>
</div>


<?php get_footer(); ?>
